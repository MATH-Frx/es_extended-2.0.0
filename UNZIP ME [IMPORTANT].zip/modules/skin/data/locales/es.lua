Translations = {
  ['skin_menu'] = 'Menú de skin',
  ['use_rotate_view'] = 'presiona ~INPUT_VEH_FLY_ROLL_LEFT_ONLY~ y ~INPUT_VEH_FLY_ROLL_RIGHT_ONLY~ para girar la vista.',
  ['skin'] = 'cambiar skin',
  ['saveskin'] = 'guardar skin en un archivo',
}
 