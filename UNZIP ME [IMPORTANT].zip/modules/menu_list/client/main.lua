local Menu = M('ui.menu')

Menu.RegisterType(self.MenuType, self.openMenu, self.closeMenu)
