Translations= {
  ['voice']   = '~y~목소리: ~s~%s',
  ['normal']  = '보통',
  ['shout']   = '외침',
  ['whisper'] = '속삭임',
}
