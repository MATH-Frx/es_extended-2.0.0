Translations= {
  ['voice']   = '~y~Nivel de voz: ~s~%s',
  ['normal']  = 'normal',
  ['shout']   = 'gritando',
  ['whisper'] = 'susurrando',
}
