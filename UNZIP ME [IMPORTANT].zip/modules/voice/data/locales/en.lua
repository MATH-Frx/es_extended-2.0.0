Translations= {
  ['voice']   = '~y~Voice: ~s~%s',
  ['normal']  = 'normal',
  ['shout']   = 'shout',
  ['whisper'] = 'whisper',
}
